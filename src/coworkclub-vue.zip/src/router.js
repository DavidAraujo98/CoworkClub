import Vue from 'vue'
import Router from 'vue-router'
import Meta from 'vue-meta'

import Book from './views/book'
import Spaces from './views/spaces'
import Space from './views/space'
import Home from './views/home'
import Profile from './views/profile'
import './style.css'

Vue.use(Router)
Vue.use(Meta)
export default new Router({
  mode: 'history',
  routes: [
    {
      name: 'Book',
      path: '/book',
      component: Book,
    },
    {
      name: 'Spaces',
      path: '/spaces',
      component: Spaces,
    },
    {
      name: 'Space',
      path: '/space',
      component: Space,
    },
    {
      name: 'Home',
      path: '/',
      component: Home,
    },
    {
      name: 'Profile',
      path: '/profile',
      component: Profile,
    },
  ],
})
