<template>
  <div class="profile-container">
    <header-logged rootClassName="header-logged-root-class-name3"></header-logged>
    <div class="profile-hero">
      <div class="profile-container01">
        <img
          src="https://play.teleporthq.io/static/svg/default-img.svg"
          alt="image"
          class="profile-image"
        />
        <div class="profile-container02">
          <h1 class="profile-text">John Doe</h1>
          <div class="profile-container03">
            <div class="profile-container04">
              <h3 class="profile-text01">Job type</h3>
              <span>Software Developer</span>
            </div>
            <div class="profile-container05">
              <h3 class="profile-text03"><span>Preferred office type</span></h3>
              <span>Hot Desk</span>
            </div>
          </div>
        </div>
      </div>
      <div class="profile-modal">
        <h2 class="profile-text06"><span>Personal details</span></h2>
        <div class="profile-table">
          <div class="profile-container06">
            <div class="profile-container07">
              <h3>Name</h3>
              <span><span>John William Doe</span></span>
            </div>
            <svg viewBox="0 0 865.7188571428571 1024" class="profile-icon">
              <path
                d="M207.429 877.714l52-52-134.286-134.286-52 52v61.143h73.143v73.143h61.143zM506.286 347.429c0-7.429-5.143-12.571-12.571-12.571-3.429 0-6.857 1.143-9.714 4l-309.714 309.714c-2.857 2.857-4 6.286-4 9.714 0 7.429 5.143 12.571 12.571 12.571 3.429 0 6.857-1.143 9.714-4l309.714-309.714c2.857-2.857 4-6.286 4-9.714zM475.429 237.714l237.714 237.714-475.429 475.429h-237.714v-237.714zM865.714 292.571c0 19.429-8 38.286-21.143 51.429l-94.857 94.857-237.714-237.714 94.857-94.286c13.143-13.714 32-21.714 51.429-21.714s38.286 8 52 21.714l134.286 133.714c13.143 13.714 21.143 32.571 21.143 52z"
              ></path>
            </svg>
          </div>
          <div class="profile-container08">
            <div class="profile-container09">
              <h3>Email</h3>
              <span><span>john_doe@email.com</span></span>
            </div>
            <svg viewBox="0 0 865.7188571428571 1024" class="profile-icon2">
              <path
                d="M207.429 877.714l52-52-134.286-134.286-52 52v61.143h73.143v73.143h61.143zM506.286 347.429c0-7.429-5.143-12.571-12.571-12.571-3.429 0-6.857 1.143-9.714 4l-309.714 309.714c-2.857 2.857-4 6.286-4 9.714 0 7.429 5.143 12.571 12.571 12.571 3.429 0 6.857-1.143 9.714-4l309.714-309.714c2.857-2.857 4-6.286 4-9.714zM475.429 237.714l237.714 237.714-475.429 475.429h-237.714v-237.714zM865.714 292.571c0 19.429-8 38.286-21.143 51.429l-94.857 94.857-237.714-237.714 94.857-94.286c13.143-13.714 32-21.714 51.429-21.714s38.286 8 52 21.714l134.286 133.714c13.143 13.714 21.143 32.571 21.143 52z"
              ></path>
            </svg>
          </div>
          <div class="profile-container10">
            <div class="profile-container11">
              <h3>Password</h3>
              <span><span>●●●●●●●●●●●●●</span></span>
            </div>
            <svg viewBox="0 0 865.7188571428571 1024" class="profile-icon4">
              <path
                d="M207.429 877.714l52-52-134.286-134.286-52 52v61.143h73.143v73.143h61.143zM506.286 347.429c0-7.429-5.143-12.571-12.571-12.571-3.429 0-6.857 1.143-9.714 4l-309.714 309.714c-2.857 2.857-4 6.286-4 9.714 0 7.429 5.143 12.571 12.571 12.571 3.429 0 6.857-1.143 9.714-4l309.714-309.714c2.857-2.857 4-6.286 4-9.714zM475.429 237.714l237.714 237.714-475.429 475.429h-237.714v-237.714zM865.714 292.571c0 19.429-8 38.286-21.143 51.429l-94.857 94.857-237.714-237.714 94.857-94.286c13.143-13.714 32-21.714 51.429-21.714s38.286 8 52 21.714l134.286 133.714c13.143 13.714 21.143 32.571 21.143 52z"
              ></path>
            </svg>
          </div>
          <div class="profile-container12">
            <div class="profile-container13">
              <h3>Address</h3>
              <span><span>Rua 1 de Janeiro, nº 11, Coimbra, Portugal</span></span>
            </div>
            <svg viewBox="0 0 865.7188571428571 1024" class="profile-icon6">
              <path
                d="M207.429 877.714l52-52-134.286-134.286-52 52v61.143h73.143v73.143h61.143zM506.286 347.429c0-7.429-5.143-12.571-12.571-12.571-3.429 0-6.857 1.143-9.714 4l-309.714 309.714c-2.857 2.857-4 6.286-4 9.714 0 7.429 5.143 12.571 12.571 12.571 3.429 0 6.857-1.143 9.714-4l309.714-309.714c2.857-2.857 4-6.286 4-9.714zM475.429 237.714l237.714 237.714-475.429 475.429h-237.714v-237.714zM865.714 292.571c0 19.429-8 38.286-21.143 51.429l-94.857 94.857-237.714-237.714 94.857-94.286c13.143-13.714 32-21.714 51.429-21.714s38.286 8 52 21.714l134.286 133.714c13.143 13.714 21.143 32.571 21.143 52z"
              ></path>
            </svg>
          </div>
        </div>
      </div>
    </div>
    <app-footer rootClassName="footer-root-class-name1"></app-footer>
  </div>
</template>

<script>
import HeaderLogged from '../components/header-logged'
import AppFooter from '../components/footer'

export default {
  name: 'Profile',
  components: {
    HeaderLogged,
    AppFooter,
  },
  metaInfo: {
    title: 'Profile - CoworkClub',
    meta: [
      {
        property: 'og:title',
        content: 'Profile - CoworkClub',
      },
    ],
  },
}
</script>

<style scoped>
.profile-container {
  width: 100%;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: center;
  flex-direction: column;
  justify-content: space-between;
}
.profile-hero {
  width: 100%;
  display: flex;
  padding: 48px;
  max-width: 1400px;
  margin-top: var(--dl-space-space-sixunits);
  min-height: 80vh;
  align-items: flex-start;
  flex-direction: column;
  justify-content: flex-start;
}
.profile-container01 {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  flex-direction: row;
  justify-content: flex-start;
}
.profile-image {
  width: 200px;
  height: 100%;
  object-fit: cover;
  margin-right: var(--dl-space-space-doubleunit);
}
.profile-container02 {
  height: auto;
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: flex-start;
}
.profile-text {
  color: var(--dl-color-primary-500);
  font-size: 3em;
}
.profile-container03 {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  flex-direction: row;
  justify-content: flex-start;
}
.profile-container04 {
  display: flex;
  align-items: flex-start;
  margin-right: var(--dl-space-space-doubleunit);
  flex-direction: column;
  justify-content: flex-start;
}
.profile-text01 {
  color: var(--dl-color-secondary-500);
}
.profile-container05 {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: flex-start;
}
.profile-text03 {
  color: var(--dl-color-secondary-500);
}
.profile-modal {
  width: 100%;
  display: flex;
  margin-top: var(--dl-space-space-doubleunit);
  align-items: flex-start;
  flex-direction: column;
  justify-content: flex-start;
}
.profile-text06 {
  color: var(--dl-color-secondary-500);
  width: 100%;
}
.profile-table {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  box-shadow: 5px 5px 10px 0px #d4d4d4;
  align-items: flex-start;
  padding-top: var(--dl-space-space-halfunit);
  border-color: var(--dl-color-gray-800);
  border-width: 1px;
  padding-left: var(--dl-space-space-unit);
  border-radius: var(--dl-radius-radius-radius40);
  padding-right: var(--dl-space-space-unit);
  flex-direction: column;
  padding-bottom: var(--dl-space-space-halfunit);
  justify-content: space-between;
}
.profile-container06 {
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.profile-container07 {
  display: flex;
  margin-top: var(--dl-space-space-halfunit);
  align-items: flex-start;
  margin-bottom: var(--dl-space-space-halfunit);
  flex-direction: column;
  justify-content: space-between;
}
.profile-icon {
  width: 24px;
  height: 24px;
}
.profile-container08 {
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.profile-container09 {
  display: flex;
  margin-top: var(--dl-space-space-halfunit);
  align-items: flex-start;
  margin-bottom: var(--dl-space-space-halfunit);
  flex-direction: column;
  justify-content: space-between;
}
.profile-icon2 {
  width: 24px;
  height: 24px;
}
.profile-container10 {
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.profile-container11 {
  display: flex;
  margin-top: var(--dl-space-space-halfunit);
  align-items: flex-start;
  margin-bottom: var(--dl-space-space-halfunit);
  flex-direction: column;
  justify-content: space-between;
}
.profile-icon4 {
  width: 24px;
  height: 24px;
}
.profile-container12 {
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.profile-container13 {
  display: flex;
  margin-top: var(--dl-space-space-halfunit);
  align-items: flex-start;
  margin-bottom: var(--dl-space-space-halfunit);
  flex-direction: column;
  justify-content: space-between;
}
.profile-icon6 {
  width: 24px;
  height: 24px;
}
@media(max-width: 991px) {
  .profile-hero {
    flex-direction: column;
  }
}
@media(max-width: 767px) {
  .profile-hero {
    padding-left: 32px;
    padding-right: 32px;
  }
}
@media(max-width: 479px) {
  .profile-hero {
    padding-top: 32px;
    padding-left: var(--dl-space-space-unit);
    padding-right: var(--dl-space-space-unit);
    padding-bottom: 32px;
  }
}
</style>
