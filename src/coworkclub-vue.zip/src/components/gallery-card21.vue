<template>
  <div class="gallery-card21-gallery-card" v-bind:class="rootClassName">
    <div class="gallery-card21-container">
      <div class="gallery-card21-container1">
        <h2 class="gallery-card21-text">{{ title }}</h2>
        <span class="gallery-card21-text1">{{ description }}</span>
        <span class="gallery-card21-text2">SHOW MORE</span>
      </div>
    </div>
    <img :alt="image_alt" :src="image_src" class="gallery-card21-image" />
  </div>
</template>

<script>
export default {
  name: 'GalleryCard21',
  props: {
    title: {
      type: String,
      default: 'Project Title',
    },
    image_alt: {
      type: String,
      default: 'image',
    },
    description: {
      type: String,
      default: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    },
    rootClassName: String,
    image_src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1484980972926-edee96e0960d?ixid=Mnw5MTMyMXwwfDF8c2VhcmNofDI0fHxmb29kfGVufDB8fHx8MTYyNjQ0OTIzNQ&ixlib=rb-1.2.1&h=1000',
    },
  },
}
</script>

<style scoped>
.gallery-card21-gallery-card {
  width: 100%;
  height: 100%;
  display: flex;
  position: relative;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.gallery-card21-container {
  width: 100%;
  height: 100%;
  display: flex;
  opacity: 0;
  z-index: 1;
  transition: 0.3s;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: #00000096;
}
.gallery-card21-container:hover {
  opacity: 1;
}
.gallery-card21-container1 {
  width: 100%;
  height: 100%;
  display: flex;
  padding: 32px;
  align-items: center;
  flex-direction: column;
  justify-content: center;
}
.gallery-card21-text {
  color: var(--dl-color-gray-white);
  font-style: normal;
  text-align: center;
  font-weight: 500;
  margin-bottom: 24px;
}
.gallery-card21-text1 {
  color: var(--dl-color-gray-white);
  text-align: center;
  margin-bottom: 24px;
}
.gallery-card21-text2 {
  color: var(--dl-color-gray-white);
  font-style: normal;
  font-weight: 700;
  text-transform: uppercase;
}
.gallery-card21-image {
  top: 0px;
  left: auto;
  right: 0px;
  width: 100%;
  bottom: auto;
  height: 100%;
  position: absolute;
  object-fit: cover;
}
.gallery-card21-root-class-name {
  flex: 1;
}


.gallery-card21-root-class-name4 {
  flex: 1;
  height: 100%;
}

@media(max-width: 767px) {
  .gallery-card21-gallery-card {
    flex-direction: column;
  }
}
@media(max-width: 479px) {
  .gallery-card21-container {
    max-width: auto;
  }
  .gallery-card21-image {
    top: 0px;
    left: 0px;
    right: auto;
    bottom: auto;
  }
}
</style>
